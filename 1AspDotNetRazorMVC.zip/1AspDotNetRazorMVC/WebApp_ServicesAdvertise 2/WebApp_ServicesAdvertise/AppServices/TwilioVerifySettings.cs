﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApp_ServicesAdvertise.AppServices
{
    public class TwilioVerifySettings
    {
        public string VerificationServiceSID { get; set; }
    }
}
