﻿
using WebApp_ServicesAdvertise.EmailModel;
using System.Threading.Tasks;
namespace WebApp_ServicesAdvertise.AppServices
{
    public interface IMailService
    {
        Task SendEmailAsync(MailRequest mailRequest);

    }
}