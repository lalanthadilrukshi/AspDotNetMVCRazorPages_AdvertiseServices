namespace WebApp_ServicesAdvertise.Configuration
{
    public class Twilio
    {
        public string AccountSid { get; set; } = "ACe84ea1c5f20dc4f0b18410a77428c0da";
        public string AuthToken { get; set; } = "1b94376d36e4cc9c6146b96b2b0700e8";
        public string VerificationSid { get; set; } = "VAe8982b66feff269c538d2430417837bb";
    }


}