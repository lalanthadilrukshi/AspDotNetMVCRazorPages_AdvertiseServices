﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApp_ServicesAdvertise.Models
{
    public class ServiceCreateModel
    {
       
        public int ld { get; set; }
       
        public int FKVillageld { get; set; }

      
        public int FKSubCategoryld { get; set; }

       
        public string FKUserld { get; set; }

       


        [DataType(DataType.Date)]
       
        public DateTime RegisterDate { get; set; }


        [DataType(DataType.Date)]
       
        public DateTime LastUpdateDate { get; set; }


        public string Name { get; set; }

        public string email { get; set; }

        
        [Phone] public string PhoneNumber { get; set; }
       

        public string workExperience { get; set; }
        public string Qualifications { get; set; }

        public string rates { get; set; }

       
        public Boolean EditMode = false;
       

      
        public List<Service_Image> Service_Images { get; set; }


        public String SubcatgoryName = "";
        public String VillageName = "";
        public List<WebApp_ServicesAdvertise.Models.City> Citys { get; set; }
        public List<WebApp_ServicesAdvertise.Models.MainCategory> MainCategorys { get; set; }
      //  public List<WebApp_ServicesAdvertise.Models.Village> AllVillages { get; set; }
       // public List<WebApp_ServicesAdvertise.Models.SubCategory> SubCategorys { get; set; }

        // public SelectList SubCategorys ;
        // public SelectList Villages  ;
    }
}
