﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Http;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;


namespace WebApp_ServicesAdvertise.Models.ViewModels
{
    public class UserUpdateModel: RegisterViewModel
    {
        [DataType(DataType.Upload)]
        [Display(Name = "Profile Picture")]
        [DisplayName("Upload File")]
        public IFormFile ImageFile { get; set; }
    }
}
