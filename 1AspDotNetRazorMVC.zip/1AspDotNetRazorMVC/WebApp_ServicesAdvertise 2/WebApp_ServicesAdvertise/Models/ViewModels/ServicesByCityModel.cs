﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApp_ServicesAdvertise.Models.ViewModels
{
    public class ServicesByCityModel
    {
        public int? CityId { get; set; }
        public int? SubCategoryId { get; set; }
        public string viewtitle;
        public List<WebApp_ServicesAdvertise.Models.City> Allcities { get; set; }
        public List<WebApp_ServicesAdvertise.Models.City> cities { get; set; }
        //public List<WebApp_ServicesAdvertise.Models.District> Districts { get; set; }
       // public List<WebApp_ServicesAdvertise.Models.Service> Services { get; set; }
       // public List<WebApp_ServicesAdvertise.Models.SubCategory> SubCategorys { get; set; }
        public List<WebApp_ServicesAdvertise.Models.MainCategory> MainCategorys { get; set; }
    }
}
