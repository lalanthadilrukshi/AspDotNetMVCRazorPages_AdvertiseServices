﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using WebApp_ServicesAdvertise.Models;

namespace WebApp_ServicesAdvertise.Models.ViewModels
{
    public class RegisterViewModel: ApplicationUser
    {
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }


        [DataType(DataType.Password)]
        [Display (Name="Confirm password")]
        [Compare("Password", ErrorMessage = "Password and confirmation password do no match")]
        public string ConfirmPassword { get; set; }
        
    }
}
