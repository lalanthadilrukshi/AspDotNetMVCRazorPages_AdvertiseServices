﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApp_ServicesAdvertise.Models.ViewModels
{
    public class ServiceViewModel
    {
       // public List<Service>? Services { get; set; }
      //  public SelectList? Genres { get; set; }t 
      //  public string? MovieGenre { get; set; }
        public int? villageId { get; set; }
        public int? SubCategoryId { get; set; }
         //public IEnumerable<WebApp_ServicesAdvertise.Models.Service> Services { get; set; }
       public List<WebApp_ServicesAdvertise.Models.Service> Services { get; set; }
   
    

        public List<WebApp_ServicesAdvertise.Models.Village> Villages { get; set; }
        public List<WebApp_ServicesAdvertise.Models.SubCategory> SubCategorys { get; set; }
    }
}
