﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebApp_ServicesAdvertise.Models;

namespace WebApp_ServicesAdvertise.Models
{
    public static class ModelBuilderExtenstions
    {
        public static void Seed(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Province>().HasData(
            new Province { ld = 1, Name = "Western" },
            new Province { ld = 2, Name = "North Western" },
            new Province { ld = 3, Name = "Northern" }
        ) ;
            modelBuilder.Entity<District>().HasData(
           new District { FKProvinceld=1, ld = 1, Name = "Colombo" },
            new District { FKProvinceld = 1, ld = 2, Name = "Gampaha" },
           new District { FKProvinceld = 3, ld = 3, Name = "Jafna" }
       );

            modelBuilder.Entity<City>().HasData(


                 new City { FKDistrictld = 1, ld = 1, Name = "Colombo" },
                        new City { FKDistrictld = 1, ld = 2, Name = "Dehiwala" },
                       new City { FKDistrictld = 1, ld = 3, Name = "Kaduwela" },
                       new City { FKDistrictld = 1, ld = 4, Name = "Moratuwa" },
                        new City { FKDistrictld = 1, ld = 5, Name = "Sri Jayawardenapura Kotte" },
                       new City { FKDistrictld = 1, ld = 6, Name = "Kolonnawa" },
                        new City { FKDistrictld = 1, ld = 7, Name = "Seethawaka" },
                        new City { FKDistrictld = 1, ld = 8, Name = "Maharagama" },
                       new City { FKDistrictld = 1, ld = 9, Name = "Kesbewa" },
                       new City { FKDistrictld = 1, ld = 10, Name = "Boralesgamuwa" },
                        new City { FKDistrictld = 1, ld = 11, Name = "Kotikawatta Mulleriyawa" },
                       new City { FKDistrictld = 1, ld = 12, Name = "Seethawakapura" },
                       new City { FKDistrictld = 1, ld = 13, Name = "Homagama" },

                        new City { FKDistrictld = 2, ld = 14, Name = "Gampaha" },
                        new City { FKDistrictld = 2, ld = 15, Name = "Negombo" },
                       new City { FKDistrictld = 2, ld = 16, Name = "Katana-Seduwa" },
                       new City { FKDistrictld = 2, ld = 17, Name = "Jaela" },
                        new City { FKDistrictld = 2, ld = 18, Name = "Wattala-Maboal" },
                       new City { FKDistrictld = 2, ld = 19, Name = "Peliyagoda" },
                        new City { FKDistrictld = 2, ld = 20, Name = "Minuwangoda" },
                        new City { FKDistrictld = 2, ld = 21, Name = "Aththanagalla" },
                       new City { FKDistrictld = 2, ld = 22, Name = "Biyagama" },
                       new City { FKDistrictld = 2, ld = 23, Name = "Divulapitiya" },
                        new City { FKDistrictld = 2, ld = 24, Name = "Dompe" },
                         new City { FKDistrictld = 2, ld = 25, Name = "Kelaniya" },
                        new City { FKDistrictld = 2, ld = 26, Name = "Mahara" },
                       new City { FKDistrictld = 2, ld = 27, Name = "Meerigama" }

                       

                   );

            modelBuilder.Entity<Village>().HasData(
                 // suburbs of Colombo  FKCityld = 1

                 //### if Id is not give the following error messaged is sent from the PackageManagerConsole when adding a migration
                 //### The seed entity for entity type 'Village' cannot be added because a non-zero value is required for property 'ld'. Consider providing a negative value to avoid collisions with non-seed data.



                 new Village { FKCityld = 1, ld = 101, Name = "Pettah" },
                  new Village { FKCityld = 1, ld = 102, Name = "Modera" },
                   new Village { FKCityld = 1, ld = 103, Name = "Kotahena" },

                        // suburbs of Colombo  FKCityld = 2 , Dehiwela
                        new Village { FKCityld = 2, ld = 201, Name = "Dehiwala" },
                        new Village { FKCityld = 2, ld = 202, Name = "Mount-Lavinia" },
                        new Village { FKCityld = 2, ld = 203, Name = "Pepiliyana" },

                       new Village { FKCityld = 3, ld = 301, Name = "Malabe" },
                       new Village { FKCityld = 3, ld = 302, Name = "Athurugiriya" },

                       new Village { FKCityld = 4, ld = 401, Name = "Moratuwa" },
                        new Village { FKCityld = 4, ld = 402, Name = "Lunawa" },

                       // new Village { FKCityld = 5, ld = 501, Name = "Sri Jayawardenapura Kotte" },
                       new Village { FKCityld = 6, ld = 601, Name = "Kolonnawa" },
                        new Village { FKCityld = 6, ld = 602, Name = "Wellampitiya" },

                        new Village { FKCityld = 7, ld = 701, Name = "Seethawaka" },
                        new Village { FKCityld = 8, ld = 801, Name = "Maharagama" },
                        new Village { FKCityld = 8, ld = 802, Name = "Kottawa" },

                       new Village { FKCityld = 9, ld = 901, Name = "Kesbewa" },
                       new Village { FKCityld = 9, ld = 902, Name = "Piliyandala" },

                       new Village { FKCityld = 10, ld = 1001, Name = "Boralesgamuwa" },
                       new Village { FKCityld = 10, ld = 1002, Name = "Delkanda" },

                        new Village { FKCityld = 11, ld = 1101, Name = "Kotikawatta" },
                        new Village { FKCityld = 11, ld = 1102, Name = "Mulleriyawa" },
                        new Village { FKCityld = 11, ld = 1103, Name = "Himbutana" },


                       new Village { FKCityld = 12, ld = 1201, Name = "Seethawakapura" },
                       new Village { FKCityld = 13, ld = 1301, Name = "Homagama" },
                       new Village { FKCityld = 13, ld = 1302, Name = "Pitipana" },
                       new Village { FKCityld = 13, ld = 1303, Name = "Kiriwanthuduwa" },


                        new Village { FKCityld = 14, ld = 1401, Name = "Gampaha" },
                        new Village { FKCityld = 14, ld = 1402, Name = "Udugampola" },

                        new Village { FKCityld = 15, ld = 1501, Name = "Negombo" },
                        new Village { FKCityld = 15, ld = 1502, Name = "Sarukkuwa" },

                       new Village { FKCityld = 16, ld = 1601, Name = "Katana-Seduwa" },
                       new Village { FKCityld = 17, ld = 1701, Name = "Jaela" },
                        new Village { FKCityld = 18, ld = 1801, Name = "Maboal" },
                         new Village { FKCityld = 18, ld = 1802, Name = "Wattala" },
                         new Village { FKCityld = 18, ld = 1803, Name = "Kandana" },

                       new Village { FKCityld = 19, ld = 1901, Name = "Peliyagoda" },
                        new Village{ FKCityld = 20, ld = 2001, Name = "Minuwangoda" },

                        new Village { FKCityld = 21, ld = 2101, Name = "Nittambuwa" },
                        new Village { FKCityld = 21, ld = 2102, Name = "Aththanagalla" },
                        new Village { FKCityld = 21, ld = 2103, Name = "Thihariya" },

                       new Village { FKCityld = 22, ld = 2201, Name = "Biyagama" },
                       new Village { FKCityld = 23, ld = 2301, Name = "Divulapitiya" },
                        new Village { FKCityld = 24, ld = 2401, Name = "Dompe" },
                        new Village { FKCityld = 24, ld = 2402, Name = "Kirindiwela" },

                         new Village { FKCityld = 25, ld = 2501, Name = "Kelaniya" },
                         new Village { FKCityld = 25, ld = 2502, Name = "Kelani Mulla" },

                        new Village { FKCityld = 26, ld = 2601, Name = "Mahara" },
                         new Village { FKCityld = 26, ld = 2602, Name = "Kadawatha" },
                         new Village { FKCityld = 26, ld = 2603, Name = "Balummahara" },

                       new Village { FKCityld = 27, ld = 2701, Name = "Meerigama" }


                     
                  );

            modelBuilder.Entity<MainCategory>().HasData(
                    new MainCategory {  ld = 1, Name = "IT" },
                     new MainCategory { ld = 2, Name = "Medical" },
                     new MainCategory { ld = 3, Name = "Hygien" },
                     new MainCategory { ld = 4, Name = "Education and Training" },
                     new MainCategory { ld = 5, Name = "Sports" },
                     new MainCategory { ld = 6, Name = "Entertainment-music/performing-arts" },
                     new MainCategory { ld = 7, Name = "Mechanical" },
                     new MainCategory { ld = 8, Name = "Construction and house repairs" },
                     new MainCategory { ld = 9, Name = "Automobile" },
                     new MainCategory { ld = 10, Name = "Legal" },
                     new MainCategory { ld = 11, Name = "Transport" },
                     new MainCategory { ld = 12, Name = "Media" },
                     new MainCategory { ld = 13, Name = "Video and Photography" },
                     new MainCategory { ld = 14, Name = "Advertising" },
                     new MainCategory { ld = 15, Name = "Events" },
                     new MainCategory { ld = 16, Name = "Community services" },
                    new MainCategory {  ld = 17, Name = "Care" },
                    new MainCategory { ld = 18, Name = "Clerical" },
                    new MainCategory { ld = 19, Name = "Labour" },
                    new MainCategory { ld = 20, Name = "Plantation and landscape" },
                    new MainCategory { ld = 21, Name = "Mobile" },
                    new MainCategory { ld = 22, Name = "Office" }
                );
            modelBuilder.Entity<SubCategory>().HasData(
                    // new SubCategory { FKCategoryld=1, ld = 1, Name = "Software Engineer" },
                    //  new SubCategory { FKCategoryld=1,ld = 2, Name = "Computer Repairs" },
                    // new SubCategory { FKCategoryld=2, ld = 3, Name = "Doctor" }
                    //### if Id is not give the following error messaged is sent from the PackageManagerConsole when adding a migration
                   //### The seed entity for entity type 'SubCategory' cannot be added because a non - zero value is required for property 'ld'.Consider providing a negative value to avoid collisions with non - seed data.
  

                      new SubCategory { FKCategoryld = 1, ld = 101, Name = "Software engineering" },
                    new SubCategory { FKCategoryld = 1, ld = 102, Name = "Computer repairs" },

                     new SubCategory { FKCategoryld = 2, ld = 201, Name = "Doctor" },
                     new SubCategory { FKCategoryld = 2, ld = 202, Name = "Doctor-Telemedicine" },
                                        
                     new SubCategory { FKCategoryld = 3, ld = 301, Name = "Cleaning and genital services" },
                     new SubCategory { FKCategoryld = 3, ld = 302, Name = "Environment cleaning" },

                     new SubCategory { FKCategoryld = 4, ld = 401, Name = "Private tutor" },
                      new SubCategory { FKCategoryld = 4, ld = 402, Name = "Speach and hearing training" },
                     
                     new SubCategory { FKCategoryld = 5, ld = 501, Name = "Training" },
                      new SubCategory { FKCategoryld = 5, ld = 502, Name = "Clubs" },

                     new SubCategory { FKCategoryld = 6, ld = 601, Name = "Music bands" },
                      new SubCategory { FKCategoryld = 6, ld = 602, Name = "DJ" },
                       new SubCategory { FKCategoryld = 6, ld = 603, Name = "Dance troupe" },
                        new SubCategory { FKCategoryld = 6, ld = 604, Name = "Drama and film" },


                     new SubCategory { FKCategoryld = 7, ld = 701, Name = "Mobile engine repairs" },
                      new SubCategory { FKCategoryld = 7, ld = 702, Name = "Machine repairs" },
                      
                     new SubCategory { FKCategoryld = 8, ld = 801, Name = "Masonry" },
                        new SubCategory { FKCategoryld = 8, ld = 802, Name = "Wood work" },
                           new SubCategory { FKCategoryld = 8, ld = 803, Name = "Electrical and wiring" },
                              new SubCategory { FKCategoryld = 8, ld = 804, Name = "Plumbing" },

                     new SubCategory { FKCategoryld = 9, ld = 901, Name = "Car wash" },
                        new SubCategory { FKCategoryld = 9, ld = 902, Name = "Car detailing" },

                     new SubCategory { FKCategoryld = 10, ld = 1001, Name = "Attorney at law" },

                     new SubCategory { FKCategoryld = 11, ld = 1101, Name = "Vehicles for hire" },
                     new SubCategory { FKCategoryld = 11, ld = 1102, Name = "Drivers" },
                     new SubCategory { FKCategoryld = 11, ld = 1103, Name = "Movers" },


                     new SubCategory { FKCategoryld = 12, ld = 1201, Name = "News reporting" },
                     

                     new SubCategory { FKCategoryld = 13, ld = 1301, Name = "Photography" },
                     new SubCategory { FKCategoryld = 13, ld = 1302, Name = "Video" },

                     // new SubCategory { FKCategoryld = 14, ld = 1401,  Name = "Advertising" },
                     new SubCategory { FKCategoryld = 15, ld = 1501, Name = "Weddings" },
                      new SubCategory { FKCategoryld = 15, ld = 1502, Name = "Funerals" },
                       new SubCategory { FKCategoryld = 15, ld = 1503, Name = "Catering" },

                    //new SubCategory { FKCategoryld = 16, ld = 1,  Name = "Community services" },
                    new SubCategory { FKCategoryld = 17, ld = 1701, Name = "Home nursing" },
                    new SubCategory { FKCategoryld = 17, ld = 1702, Name = "Child care and baby sitting" },
                    new SubCategory { FKCategoryld = 17, ld = 1703, Name = "Aged care" },
                    new SubCategory { FKCategoryld = 17, ld = 1704, Name = "Pet care" },

                    new SubCategory { FKCategoryld = 18, ld = 1801, Name = "Type setting" },
                    new SubCategory { FKCategoryld = 18, ld = 1802, Name = "Translations" }, 

                    new SubCategory { FKCategoryld = 19, ld = 1901, Name = "Labour work" },
                    new SubCategory { FKCategoryld = 20, ld = 2001, Name = "Gardening services" },
                    new SubCategory { FKCategoryld = 20, ld = 2002, Name = "Tree felling" },
                    new SubCategory { FKCategoryld = 21, ld = 2101, Name = "Mobile repairs" },
                    new SubCategory { FKCategoryld = 22, ld = 2201, Name = "Office supplies" }



               );

         /*   modelBuilder.Entity<Service>().HasData(
                 // new Service { FKVillageld = 1, FKSubCategoryld = 1, ld = 1, Name = "Dilrukshi", BirthDate = new DateTime(1973, 11, 13, 0, 0, 0, 0, DateTimeKind.Unspecified), RegisterDate = DateTime.Today, LastUpdateDate = DateTime.Today });
            new Service { FKVillageld = 1, FKSubCategoryld = 1, ld = 1, Name = "Dilrukshi",  RegisterDate = DateTime.Today, LastUpdateDate = DateTime.Today });*/
        }
    }
}
