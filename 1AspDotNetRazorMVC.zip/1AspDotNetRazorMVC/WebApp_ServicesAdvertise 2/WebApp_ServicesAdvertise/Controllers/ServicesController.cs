﻿using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApp_ServicesAdvertise.Data;
using WebApp_ServicesAdvertise.Models;
using WebApp_ServicesAdvertise.Models.ViewModels;
using System.Collections.Generic;
using Microsoft.AspNetCore.Authorization;

namespace WebApp_ServicesAdvertise.Controllers
{

    public class ServicesController : Controller
    {
        public const int MaxPicCountForUser = 3;
        private readonly WebApp_ServicesAdvertiseContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        public const String Picfolder = "ServicePics";//create directory in wwwroot folder
        private readonly IWebHostEnvironment webHostEnvironment;
        public ServicesController(UserManager<ApplicationUser> userManager, WebApp_ServicesAdvertiseContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _userManager = userManager;
            this.webHostEnvironment = webHostEnvironment;
        }

        // GET: Services

        /*public async Task<IActionResult> Index()
        {
            var webApp_ServicesAdvertiseContext = _context.Service.Include(s => s.SubCategory).Include(s => s.Village);
            return View(await webApp_ServicesAdvertiseContext.ToListAsync());
        }*/

        // GET: Services an search 
        [AllowAnonymous]
        public async Task<IActionResult> DetailsByUser()
        {
            // Use LINQ to get list of genres.
            /* IQueryable<string> genreQuery = from m in _context.Movie
                                             orderby m.Genre
                                             select m.Genre;*/
            
string userid = _userManager.GetUserId(User);
           // var Services = _context.Service.Where(s => s.FKSubCategoryld == SubCategoryId && s.FKVillageld == villageId).Include(s => s.SubCategory).Include(s => s.Village);

            var Services = _context.Service.Where(s => s.FKUserld == userid).Include(s => s.SubCategory).Include(s => s.Village);
             

            




            var VM = new ServiceViewModel
            {
                Services = await Services.ToListAsync(),
               
            };
            //("~/Views/Account/Register.cshtml")
            return View(VM);
                    }

        // GET: Services an search
        // 
       // [AllowAnonymous]
        public async Task<IActionResult> ServicesByCity(int SubCategoryId, int CityId)
        {

            //var Services = _context.Service.Where(s => s.FKSubCategoryld == SubCategoryId && s.FKVillageld == villageId).Include(s => s.SubCategory).Include(s => s.Village).ToListAsync();
            // List<Service> Services;//= _context.Service.Where(s => s.FKSubCategoryld == SubCategoryId && s.FKVillageld == villageId).Include(s => s.SubCategory).Include(s => s.Village).ToListAsync();

            // Use LINQ to get list of genres.
            /* IQueryable<string> genreQuery = from m in _context.Movie
                                             orderby m.Genre
                                            select m.Genre;*/
            //List<Service> Services;
            // Microsoft.EntityFrameworkCore.Query.IIncludableQueryable   Services;// = _context.Service.Where(s => s.FKSubCategoryld == SubCategoryId && s.FKVillageld == villageId).Include(s => s.SubCategory).Include(s => s.Village);
            IQueryable<City> Citys;
            String viewtitle;
          //  IQueryable<Village> Villages
            if  ((SubCategoryId == 0) && (CityId == 0))
            {
                Citys = _context.City.Include(c => c.Villages).ThenInclude(v => v.Services);
                // var startDate = date.Date;
                // var endDate = startDate.AddDays(1);
                // var movieList = db.Movies.Include(x => x.Shows)
                //                        .Where(x => x.Shows.Any(x => x.DateTime >= startDate && x.DateTime < endDate)
                //                        .ToList();

                // var job = db.Jobs
                //.Include(x => x.Quotes.Select(q => q.QuoteItems))
                //.Where(x => x.JobID == id)
                //.SingleOrDefault()

                // var names = myClass1List
                //.SelectMany(c1 => c1.Class2List.Where(c2 => c2.Name == "something"))
                //.SelectMany(c2 => c2.Class3List.Select(c3 => c3.Name));

                // List<side> listNozzleBySide = SectionList.SelectMany(x => x.SideList.Where(y => y.PositionList.Any(z => z.Position >= 1 && z.Position <= 5))).ToList();

                //  IQueryable<Village> Villages
                //IQueryable<City> Citys;
                // Citys = _context.Districts.SelectMany(D=> D.Citys).SelectMany(c => c.Villages.Where(v => v.Services.Any(s =>  s.ld > 0)));

                //Citys = _context.Districts.SelectMany(D => D.Citys).SelectMany(c => c.Villages).SelectMany(v => v.Services);




                viewtitle = "All Services in all cityies";

                Citys = _context.City.Include(c => c.Villages).ThenInclude(v=> v.Services);

                // Services = _context.Service.Include(s => s.SubCategory).Include(s => s.Village);
                // Services = _context.City.Include(c=> c.Villages.Service.cities(s => s.SubCategory).Include(s => s.Village).Include(s => s.Village.City).Include(s => s.Village.City.District);
            }
             else if ((CityId == 0))
            {
                Citys = _context.City.Include(c => c.Villages).ThenInclude(v => v.Services.Where(s => s.FKSubCategoryld == SubCategoryId));
            }
            else if (SubCategoryId == 0)
             {
                Citys = _context.City.Where(c => c.ld == CityId).Include(c => c.Villages).ThenInclude(v => v.Services);
            }
             else
             {
                Citys = _context.City.Where(c => c.ld == CityId).Include(c => c.Villages).ThenInclude(v => v.Services.Where(s => s.FKSubCategoryld == SubCategoryId));
            
            }

            // var SubCategorys = _context.SubCategories;
            // var SubCategorys = _context.SubCategories.Include(c => c.MainCategory);
            //var SubCategorys = _context.SubCategories.Include(c => c.MainCategory).OrderByDescending(c=> c.MainCategory.Name);
            
            //var SubCategorys = _context.MainCategorys.OrderBy(m=>m.Name).SelectMany(m=>m.SubCategorys);
           // var SubCategorys = _context.SubCategories.OrderBy(m => m.Name);

            var Categorys = _context.MainCategorys.Include(s=> s.SubCategorys).OrderBy(m => m.Name);
            //  var AllCitys = _context.Districts.OrderBy(d=>d.Name).SelectMany(D=>D.Citys);
            var AllCitys = _context.City.OrderBy(d => d.Name);






            // var Villages = _context.Villages;

            // return View(await webApp_ServicesAdvertiseContext.ToListAsync());
            ServicesByCityModel VM;
           
try
            { 
 VM = new ServicesByCityModel
            {
                // Services = await Services.ToListAsync(),
                 
                Allcities = await AllCitys.ToListAsync(),
               // SubCategorys = await SubCategorys.ToListAsync(),
                MainCategorys = await Categorys.ToListAsync(),
                cities = await Citys.ToListAsync(),
                SubCategoryId = SubCategoryId,
                 CityId = CityId

            };

                String SubcatgoryName = "";
                String CityName = "";

                foreach (MainCategory m in Categorys)
                {
                    var item = m.SubCategorys.FirstOrDefault(o => o.ld == SubCategoryId);
                    if (item != null)
                    {
                        SubcatgoryName = item.Name;
                        break;
                    }
                }


                var item2 = VM.Allcities.FirstOrDefault(o => o.ld == CityId);
                if (item2 != null) CityName = item2.Name;


                if ((SubCategoryId == 0) && (CityId == 0))
                {
                    viewtitle = "All Services in all cityies";

                }
                else if ((CityId == 0))
                {
                    viewtitle = "All " + SubcatgoryName + " services ";
                }
                else if (SubCategoryId == 0)
                {
                    viewtitle = "All  services in " + CityName;
                }
                else
                {
                    viewtitle = "All " + SubcatgoryName + " services in " + CityName;
                }

                VM.viewtitle = viewtitle;

            }
            catch (Exception ex)
            {
                VM = new ServicesByCityModel  //## incase database access is not successful
                {
                    // Services = await Services.ToListAsync(),
                    Allcities = new List<WebApp_ServicesAdvertise.Models.City>(),
                    cities = new List<WebApp_ServicesAdvertise.Models.City>(),
                    MainCategorys = new List<WebApp_ServicesAdvertise.Models.MainCategory>(),
                    SubCategoryId = SubCategoryId,
                    CityId = CityId
                };
                VM.viewtitle = "error while accessing database";
            }
           





            //("~/Views/Account/Register.cshtml")
            return View("ServicesByCity",VM);



        }

        [Authorize]
        public async Task<IActionResult> UserServices()
        { // ### in the queryy the records are access from child to parent and properties city and district is returned null, even for querry   Services = _context.Service.Include(s => s.SubCategory).Include(s => s.Village).Include(s => s.Village.City).Include(s => s.Village.City.District);

            //var Services = _context.Service.Where(s => s.FKSubCategoryld == SubCategoryId && s.FKVillageld == villageId).Include(s => s.SubCategory).Include(s => s.Village).ToListAsync();
            // List<Service> Services;//= _context.Service.Where(s => s.FKSubCategoryld == SubCategoryId && s.FKVillageld == villageId).Include(s => s.SubCategory).Include(s => s.Village).ToListAsync();

            // Use LINQ to get list of genres.
            /* IQueryable<string> genreQuery = from m in _context.Movie
                                             orderby m.Genre
                                            select m.Genre;*/
            //List<Service> Services;
            // Microsoft.EntityFrameworkCore.Query.IIncludableQueryable   Services;// = _context.Service.Where(s => s.FKSubCategoryld == SubCategoryId && s.FKVillageld == villageId).Include(s => s.SubCategory).Include(s => s.Village);
            IQueryable<Service> Services;
            String userid = _userManager.GetUserId(User);

            // ### Services = _context.Districts.SelectMany(D => D.Citys).SelectMany(c => c.Villages).SelectMany(v => v.Services); ;
            //  Services = _context.City.SelectMany(c => c.Villages).SelectMany(v => v.Services.Where(s => s.FKUserld== userid));
        
            //Services =  _context.Service.Where(s => s.FKUserld == userid).Include(s => s.SubCategory).Include(s => s.Village);
            Services = _context.Service.Where(s => s.FKUserld == userid).Include(s => s.SubCategory).Include(s => s.Village).ThenInclude(c => c.City);

            var VM = new ServiceViewModel
            {
                Services = await Services.ToListAsync()
  
               
            };
            //("~/Views/Account/Register.cshtml")
            return View("UserServices",VM);
         
        }






        // GET: Services/Details/5
        [AllowAnonymous]
        public async Task<IActionResult> Details_notinuse(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            /*var service = await _context.Service
                .Include(s => s.SubCategory)
                .Include(s => s.Village)
                .FirstOrDefaultAsync(m => m.ld == id);*/

            var service = await _context.Service.Include(s => s.SubCategory).Include(s => s.Village).Include(Im => Im.Service_Images).FirstOrDefaultAsync(m => m.ld == id);

           








            if (service == null)
            {
                return NotFound();
            }

            return View(service);
        }

        // GET: Services/Create
        public IActionResult Create_notinuse()
        {



            //auto generate code
            // ViewData["FKSubCategoryld"] = new SelectList(_context.Set<SubCategory>(), "ld", "service type");
            // ViewData["FKVillageld"] = new SelectList(_context.Set<Village>(), "ld", "village");
            //### ViewData["CreatedUserID"] = User.Identity.Name;
            ServiceCreateModel serviceCreateModel = new ServiceCreateModel();
            var SubCategorys = _context.SubCategories;
            var Villages = _context.Villages;

            // ViewData["FKSubCategoryld"] = new SelectList(SubCategorys, "ld", "Name");// "ld", "Name" represents columns from database table that will be used for value and text in drop down list
            //ViewData["FKVillageld"] = new SelectList(Villages, "ld", "Name");// "ld", "Name" represents columns from database table that will be used for value and text in drop down list
          //  serviceCreateModel.SubCategorys = new SelectList(SubCategorys, "ld", "Name");// "ld", "Name" represents columns from database table that will be used for value and text in drop down list
           // serviceCreateModel.Villages = new SelectList(Villages, "ld", "Name");// "ld", "Name" represents columns from database table that will be used for value and text in drop down list

           // serviceCreateModel.FKUserld = _userManager.GetUserName(User);
            serviceCreateModel.FKUserld = _userManager.GetUserId(User);

            return View(serviceCreateModel);
        }

        // POST: Services/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        // public async Task<IActionResult> Create([Bind("ld,FKVillageld,FKSubCategoryld,BirthDate,RegisterDate,LastUpdateDate,Name,email,contact,workExperience,Qualifications,rates,CreatedUserID")] Service service)

        [HttpPost]
        private string GetProfilePicPath_createDirIfNotExist(String FileName)
        {
            /* local variable declaration */
            //var basePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory + "/UploadedProfilePics/");
            // var basePath = System.Reflection.Assembly.GetExecutingAssembly().Location;

            string wwwRootPath = webHostEnvironment.WebRootPath;
            string basePath = Path.Combine(wwwRootPath + "\\" + Picfolder + "\\");
            bool basePathExists = System.IO.Directory.Exists(basePath);
            if (!basePathExists) Directory.CreateDirectory(basePath);


            String path = Path.Combine(basePath, FileName);
            //String path = Path.Combine("~" + "/" + ProfilePicfoler + "/", FileName);
            return path;
        }

        //public async Task<IActionResult> CreateService(Service service, IFormFile[] photos)
            public async Task<IActionResult> CreateService_noinuse(ServiceCreateModel serviceCreateModel, IFormFile[] photos)
           {
            if (ModelState.IsValid)
            {
                Service service = new Service();
                int maxCount = MaxPicCountForUser;
              //  List<Service_Image> Service_Images = new List<Service_Image>();
                //int count = 0;
                for (int i = 0; i < maxCount; i++)
                {
                    string fileName = "";
                    if (photos is not null)
                    {
                        if (i < photos.Length)
                        {

                            IFormFile file = photos[i];
                            //foreach (IFormFile file in photos)
                            // {
                            string path;
                            
                            //if (file != null)
                            // {
                            // int prevPhotosCount = 0;
                            //if (Service_Images is not null)
                            //{
                            // prevPhotosCount = Service_Images.Count;
                            // }else {
                            // Service_Images = new List<Service_Image>();
                            //}
                            // if ((prevPhotosCount) > 3)
                            //{
                            // List<Service_Image> prevImages = Service_Images.ToList();

                            // count += 1;
                            // fileName = file.FileName;//si.ImagePath;
                            // Service_Images.Remove(si);
                            //path = GetProfilePicPath_createDirIfNotExist(fileName);
                            //FileInfo fileinfo = new FileInfo(path);
                            //if (fileinfo.Exists)//check file exsit or not  
                            //{
                            //  fileinfo.Delete();
                            //}
                            // }
                            fileName = Path.GetFileNameWithoutExtension(file.FileName);
                            string extension = Path.GetExtension(file.FileName);
                            fileName = Guid.NewGuid().ToString() + extension;//global unique Id
                                                                             //Service_Image si2 = new Service_Image();
                                                                             // si2.ImagePath = fileName;
                            path = GetProfilePicPath_createDirIfNotExist(fileName);// Path.Combine(basePath, fileName);
                            using (var fileStream = new FileStream(path, FileMode.Create))
                            {
                                await file.CopyToAsync(fileStream);
                            }
                        }
                    }
                    var si = _context.Service_Images.Add(new Service_Image()
                        {
                                ImagePath= fileName
                                
                            }).Entity;
                    // Service_Image si = new Service_Image();

                    // si.ImagePath = fileName;
                    // Service_Images.Add(si2);                                             //user.ImagePath =  fileName = fileName + DateTime.Now.ToString("yymmssfff") + extension;
                    service.Service_Images.Add(si);
                            
                        }
                            
                
                service.FKSubCategoryld = serviceCreateModel.FKSubCategoryld;
                service.FKVillageld = serviceCreateModel.FKVillageld;
                service.FKUserld= serviceCreateModel.FKUserld;

                //serviceCreateModel.service.FKSubCategoryld = 1;
                // _context.Add(serviceCreateModel.service);
                _context.Service.Add(service);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
                               
            }
                      return View(serviceCreateModel);
        }

        // GET: Services/Edit/5
        //[Authorize]
        [HttpGet]
        public async Task<IActionResult> Edit(int? id, Boolean EditMode)
        {
            if (id == null)
            {
                return NotFound();
            }

            Service service;
            List<Service_Image> Service_Images;
            if (id == 0) // create new mode
            {
                EditMode = true;
                  service = new Service();
                Service_Images = new List<Service_Image>();
                service.FKUserld = _userManager.GetUserId(User);
                service.ld = 0;
            }
            else
            {
                service = await _context.Service.Include(s => s.SubCategory).Include(s => s.Village).Include(s => s.User).Include(Im => Im.Service_Images).FirstOrDefaultAsync(m => m.ld == id);
                Service_Images = await _context.Service_Images.Where(s => s.FKServiceld == id).OrderBy(i=>i.LastUpdateDate).ToListAsync();
            }

            // var service = await _context.Service.FindAsync(id);
            if (service == null)
            {
                return NotFound();
            }





            // ViewData["FKSubCategoryld"] = new SelectList(_context.Set<SubCategory>(), "ld", "ld", service.FKSubCategoryld);
            // ViewData["FKVillageld"] = new SelectList(_context.Set<Village>(), "ld", "ld", service.FKVillageld);

            // service.EditMode = EditMode;


            //var SubCategorys = _context.MainCategorys.OrderBy(m=>m.Name).SelectMany(m=>m.SubCategorys);
            var SubCategorys = _context.SubCategories.OrderBy(m => m.Name);
            //  var AllCitys = _context.Districts.OrderBy(d=>d.Name).SelectMany(D=>D.Citys);
            var AllVillages = _context.City.OrderBy(d => d.Name).SelectMany(c => c.Villages);

            String SubcatgoryName = "";
            String VillageName = "";
           // var item = SubCategorys.FirstOrDefault(o => o.ld == service.FKSubCategoryld);
           // if (item != null) SubcatgoryName = item.Name;
           // var item2 = AllVillages.FirstOrDefault(o => o.ld == service.FKVillageld);
           // // if (item2 != null) VillageName = item2.City.Name + "-" + item2.Name;
           // if (item2 != null) VillageName = item2.Name;


            var Categorys = _context.MainCategorys.Include(s => s.SubCategorys).OrderBy(m => m.Name);
            var AllCitys = _context.City.Include(c=>c.Villages).OrderBy(d => d.Name);
            foreach (MainCategory m in Categorys)
            {
                var item = m.SubCategorys.FirstOrDefault(o => o.ld == service.FKSubCategoryld);
                if (item != null)
                {
                    SubcatgoryName = item.Name;
                    break;
                }
            }
            foreach (City p  in AllCitys)
            {
                var item = p.Villages.FirstOrDefault(o => o.ld == service.FKVillageld);
                if (item != null)
                {
                    VillageName = item.Name;
                    break;
                }
            }


            var VM = new ServiceCreateModel
            {
                ld = service.ld,
                FKVillageld = service.FKVillageld,
                FKSubCategoryld = service.FKSubCategoryld,
                FKUserld = service.FKUserld,
                RegisterDate = service.RegisterDate,
                LastUpdateDate = service.LastUpdateDate,
                Name = service.Name,
                email = service.email,
                PhoneNumber = service.PhoneNumber,
                workExperience = service.workExperience,
                Qualifications = service.Qualifications,
                rates = service.rates,
                EditMode = EditMode,
                // AllVillages = await AllVillages.ToListAsync(),
                //SubCategorys = await SubCategorys.ToListAsync(),

                Citys = await AllCitys.ToListAsync(),
                MainCategorys = await Categorys.ToListAsync(),
                Service_Images = Service_Images,
                SubcatgoryName = SubcatgoryName,
                VillageName = VillageName
            };

            return View(VM);
        }
        [HttpPost]
        public async Task<IActionResult> Edit_Prev(int id, Service service, IFormFile[] photos)

        {
            String userid = _userManager.GetUserId(User);

            // ## even other users can access this method, via request for details
            if (userid == service.FKUserld)
            {
                if (id != service.ld)
                {
                    return NotFound();
                }
                if (ModelState.IsValid)
                {
                    int maxCount = MaxPicCountForUser;
                    string fileName = "";
                    if (photos is not null)
                    {
                        for (int i = 0; i < Math.Min(maxCount, photos.Length); i++)
                        {

                            IFormFile file = photos[i];
                            string path;

                            fileName = service.Service_Images.ElementAt(i).ImagePath;
                            if (fileName is not null)
                            {
                                // fileName = service.Service_Images[i].ImagePath;
                                path = GetProfilePicPath_createDirIfNotExist(fileName);
                                FileInfo fileinfo = new FileInfo(path);
                                if (fileinfo.Exists)//check file exsit or not  
                                {
                                    fileinfo.Delete();
                                }
                            }

                            string extension = Path.GetExtension(file.FileName);
                            fileName = Guid.NewGuid().ToString() + extension;//global unique Id //user.ImagePath =  fileName = fileName + DateTime.Now.ToString("yymmssfff") + extension;
                            path = GetProfilePicPath_createDirIfNotExist(fileName);// Path.Combine(basePath, fileName);
                            using (var fileStream = new FileStream(path, FileMode.Create))// this block form is needed to release resources at end of operation
                            {
                                await file.CopyToAsync(fileStream);
                            }
                            Service_Image si = service.Service_Images.ElementAt(i);
                            si.ImagePath = fileName;
                            _context.Service_Images.Update(si);
                            // db.Entry(Service_Images.ElementAt(i)).State = EntityState.Modified;
                        }
                    }

                    // db.Entry(service).State = EntityState.Modified;




                    try
                    {
                        _context.Update(service);
                        await _context.SaveChangesAsync();
                    }
                    catch (DbUpdateConcurrencyException)
                    {
                        if (!ServiceExists(service.ld))
                        {
                            return NotFound();
                        }
                        else
                        {
                            throw;
                        }
                    }
                    // return RedirectToAction(nameof(Index));
                }
                ViewData["FKSubCategoryld"] = new SelectList(_context.Set<SubCategory>(), "ld", "ld", service.FKSubCategoryld);
                ViewData["FKVillageld"] = new SelectList(_context.Set<Village>(), "ld", "ld", service.FKVillageld);
                return View(service);
            }
            else
            {
                // _logger.LogError("Attempt to update without permission");
                return StatusCode(500, "Access violation");
            }
        }

        [HttpGet]
       









        // POST: Services/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
       // [ValidateAntiForgeryToken]
        //  public async Task<IActionResult> Edit(int id, [Bind("ld,FKVillageld,FKSubCategoryld,BirthDate,RegisterDate,LastUpdateDate,Name,email,contact,workExperience,Qualifications,rates,CreatedUserID")] Service service)
        [Authorize]
        public async Task<IActionResult> Edit_Post(int id, ServiceCreateModel service, IFormFile[] photos)

        {
            String userid = _userManager.GetUserId(User);

            // ## even other users can access this method, via request for details
            if (userid == service.FKUserld)
{
               // if (id != service.ld)
               // {
                 //   return NotFound();
                //}
                if (ModelState.IsValid)
                {
                    if (service.Service_Images == null) { service.Service_Images = new List<Service_Image>(); } // when creating new service service.Service_Images is null
                    for (int i=0; i< service.Service_Images.Count; i++)
                    {
                        if ( service.Service_Images.ElementAt(i).ImagePath is null) // empty strings are returned as null for imagepath
                        {
                            service.Service_Images.ElementAt(i).ImagePath = "";
                        }
                        
                    }
                    DateTime registerdate = service.RegisterDate;
                    if (id == 0)// create new
                    { registerdate = DateTime.Now; }
                    Service oservice = new Service
                    {
                        ld = service.ld,
                        FKVillageld = service.FKVillageld,
                        FKSubCategoryld = service.FKSubCategoryld,
                        FKUserld = service.FKUserld,
                        RegisterDate = registerdate,//service.RegisterDate,
                        LastUpdateDate = DateTime.Now, //'service.LastUpdateDate,
                        Name = service.Name,
                        email = service.email,
                        PhoneNumber = service.PhoneNumber,
                        workExperience = service.workExperience,
                        Qualifications = service.Qualifications,
                        rates = service.rates,
                        Service_Images= service.Service_Images

                    };


                    /* int maxCount = MaxPicCountForUser;

                   

                     */
                    int maxCount = MaxPicCountForUser;
                    int addcount =maxCount - service.Service_Images.Count;
                    for (int i = 0; i < addcount; i++)// in the view (.cshtml) if the photopath is empty, that Service_Image item wont be added to the page, there fore in the return list of Service_Image s (in the Model)  , the  item will not be there 
                    {
                        var si = new Service_Image()
                        {
                            ImagePath = "",
                            FKServiceld = service.ld,
                             LastUpdateDate = DateTime.MinValue
                        };
                   // service.Service_Images.Add(si);
                        service.Service_Images.Insert(0,si);
                    }
                if (service.ld == 0)// service not yet created create new service and Service_Images records for images
                    {
                       /* oservice.Service_Images = new List<Service_Image>();
                        for (int i = 0; i < maxCount; i++)
                        {
                          var si =new Service_Image()
                            {
                                ImagePath = "",
                                FKServiceld = service.ld
                          };
                            oservice.Service_Images.Add(si);
                        }
                       */
                       // service.FKSubCategoryld = serviceCreateModel.FKSubCategoryld;
                       // service.FKVillageld = serviceCreateModel.FKVillageld;
                       //service.FKUserld = serviceCreateModel.FKUserld;
                        //serviceCreateModel.service.FKSubCategoryld = 1;
                        // _context.Add(serviceCreateModel.service);
                        
                        _context.Service.Add(oservice);
                        await _context.SaveChangesAsync();
                    }

                   
                    string fileName = "";
                    if (photos is not null)
                    {
                        for (int i = 0; i < Math.Min(maxCount, photos.Length); i++)
                        {

                            IFormFile file = photos[i];
                            string path;

                             
                            fileName = service.Service_Images.ElementAt(i).ImagePath;
                            if (fileName is not null)
                            {
                                // fileName = service.Service_Images[i].ImagePath;
                                path = GetProfilePicPath_createDirIfNotExist(fileName);
                                FileInfo fileinfo = new FileInfo(path);
                                if (fileinfo.Exists)//check file exsit or not  
                                {
                                    fileinfo.Delete();
                                }
                            }
                            
                            string extension = Path.GetExtension(file.FileName);
                            fileName = Guid.NewGuid().ToString() + extension;//global unique Id //user.ImagePath =  fileName = fileName + DateTime.Now.ToString("yymmssfff") + extension;
                            path = GetProfilePicPath_createDirIfNotExist(fileName);// Path.Combine(basePath, fileName);
                            using (var fileStream = new FileStream(path, FileMode.Create))// this block form is needed to release resources at end of operation
                            {
                                await file.CopyToAsync(fileStream);
                            }
                            Service_Image si = oservice.Service_Images.ElementAt(i);
                            si.ImagePath = fileName;
                            si.LastUpdateDate = DateTime.Now;
                            //si.FKServiceld = service.id;
                            _context.Service_Images.Update(si);
                            // db.Entry(Service_Images.ElementAt(i)).State = EntityState.Modified;
                        }
                    }

                    // db.Entry(service).State = EntityState.Modified;
                    try
                    {
                        _context.Update(oservice);
                        await _context.SaveChangesAsync();
                    }
                    catch (DbUpdateConcurrencyException)
                    {
                        if (!ServiceExists(service.ld))
                        {
                            return NotFound();
                        }
                        else
                        {
                            throw;
                        }
                    }
                    // return RedirectToAction(nameof(Index));
                }
                //ViewData["FKSubCategoryld"] = new SelectList(_context.Set<SubCategory>(), "ld", "ld", service.FKSubCategoryld);
                // ViewData["FKVillageld"] = new SelectList(_context.Set<Village>(), "ld", "ld", service.FKVillageld);
                return View("~/Views/Shared/MessageView.cshtml");
              
            }
            else
            {
               // _logger.LogError("Attempt to update without permission");
                return StatusCode(500, "Access violation");
            }
        }

        // GET: Services/Delete/5
        [Authorize]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var service = await _context.Service
                .Include(s => s.SubCategory)
                .Include(s => s.Village)
                .FirstOrDefaultAsync(m => m.ld == id);
            if (service == null)
            {
                return NotFound();
            }

            return View(service);
        }

        // POST: Services/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var service = await _context.Service.FindAsync(id);
                _context.Service.Remove(service);
                await _context.SaveChangesAsync();
                return View("~/Views/Shared/MessageView.cshtml");
                //return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewData["message"] = id + "   " + ex.ToString();
            }
             return View();
        }

        private bool ServiceExists(int id)
        {
            return _context.Service.Any(e => e.ld == id);
        }
    }
}
