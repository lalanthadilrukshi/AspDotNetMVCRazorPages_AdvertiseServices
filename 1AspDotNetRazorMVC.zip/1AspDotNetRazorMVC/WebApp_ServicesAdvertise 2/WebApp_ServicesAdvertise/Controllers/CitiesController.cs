﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApp_ServicesAdvertise.Models;
using WebApp_ServicesAdvertise.Data;

namespace WebApp_ServicesAdvertise.Controllers
{
    public class CitiesController : Controller
    {
        private readonly WebApp_ServicesAdvertiseContext _context;

        public CitiesController(WebApp_ServicesAdvertiseContext context)
        {
            _context = context;
        }

        // GET: Cities
       // public async Task<IActionResult> Index(int CityId)
        public async Task<IActionResult> Index()
        {
            //int CityId = 1;
            var webApp_ServicesAdvertiseContext = _context.City.Include(c => c.District).ThenInclude(d=>d.Province) ;
           // var webApp_ServicesAdvertiseContext = _context.City.Where(c => c.ld==CityId).Include(c => c.District).ThenInclude(d => d.Province);

            return View(await webApp_ServicesAdvertiseContext.ToListAsync());
        }

        // GET: Cities/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var city = await _context.City
                .Include(c => c.District)
                .FirstOrDefaultAsync(m => m.ld == id);
            if (city == null)
            {
                return NotFound();
            }

            return View(city);
        }

        // GET: Cities/Create
        public IActionResult Create()
        {
            ViewData["FKDistrictld"] = new SelectList(_context.Set<District>(), "ld", "ld");
            return View();
        }

        // POST: Cities/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ld,FKDistrictld,Name")] City city)
        {
            if (ModelState.IsValid)
            {
                _context.Add(city);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["FKDistrictld"] = new SelectList(_context.Set<District>(), "ld", "ld", city.FKDistrictld);
            return View(city);
        }

        // GET: Cities/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var city = await _context.City.FindAsync(id);
            if (city == null)
            {
                return NotFound();
            }
            ViewData["FKDistrictld"] = new SelectList(_context.Set<District>(), "ld", "ld", city.FKDistrictld);
            return View(city);
        }

        // POST: Cities/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ld,FKDistrictld,Name")] City city)
        {
            if (id != city.ld)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(city);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CityExists(city.ld))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["FKDistrictld"] = new SelectList(_context.Set<District>(), "ld", "ld", city.FKDistrictld);
            return View(city);
        }

        // GET: Cities/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var city = await _context.City
                .Include(c => c.District)
                .FirstOrDefaultAsync(m => m.ld == id);
            if (city == null)
            {
                return NotFound();
            }

            return View(city);
        }

        // POST: Cities/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var city = await _context.City.FindAsync(id);
            _context.City.Remove(city);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CityExists(int id)
        {
            return _context.City.Any(e => e.ld == id);
        }
    }
}
