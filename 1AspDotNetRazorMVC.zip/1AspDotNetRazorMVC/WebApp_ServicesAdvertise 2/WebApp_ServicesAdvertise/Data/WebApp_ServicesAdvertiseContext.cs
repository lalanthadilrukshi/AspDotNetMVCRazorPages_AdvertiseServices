﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebApp_ServicesAdvertise.Models;


using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace WebApp_ServicesAdvertise.Data
{
    //public class WebApp_ServicesAdvertiseContext :  DbContext
    //public class WebApp_ServicesAdvertiseContext : IdentityDbContext<IdentityUser, IdentityRole, string>
         public class WebApp_ServicesAdvertiseContext : IdentityDbContext<ApplicationUser, IdentityRole, string>
    {

        public WebApp_ServicesAdvertiseContext (DbContextOptions<WebApp_ServicesAdvertiseContext> options)
            : base(options)
        {
        }

        public DbSet<WebApp_ServicesAdvertise.Models.Province> Province { get; set; }
        public DbSet<WebApp_ServicesAdvertise.Models.Village> Villages { get; set; }
  
            public DbSet<WebApp_ServicesAdvertise.Models.MainCategory> MainCategorys { get; set; }
        public DbSet<WebApp_ServicesAdvertise.Models.SubCategory> SubCategories { get; set; }

        public DbSet<WebApp_ServicesAdvertise.Models.District> Districts { get; set; }
        public DbSet<WebApp_ServicesAdvertise.Models.City> City { get; set; }

       
        public DbSet<WebApp_ServicesAdvertise.Models.Service> Service { get; set; }
        public DbSet<WebApp_ServicesAdvertise.Models.Service_Image> Service_Images { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder); 


            modelBuilder.Entity<ApplicationUser>(e =>
            {
                e.HasMany(p => p.Services)
                .WithOne(p => p.User)
                .HasForeignKey(p => p.FKUserld); 
            });


            modelBuilder.Entity<Service_Image>()
        .HasOne<Service>(p => p.service)
        .WithMany(q => q.Service_Images)
        .HasForeignKey(r => r.FKServiceld);




            modelBuilder.Seed();

        }
    }
}
