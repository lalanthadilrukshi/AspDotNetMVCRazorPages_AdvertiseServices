using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApp_ServicesAdvertise.Areas.Identity.Pages.Account.Manage
{
    public class ErrorMessageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
