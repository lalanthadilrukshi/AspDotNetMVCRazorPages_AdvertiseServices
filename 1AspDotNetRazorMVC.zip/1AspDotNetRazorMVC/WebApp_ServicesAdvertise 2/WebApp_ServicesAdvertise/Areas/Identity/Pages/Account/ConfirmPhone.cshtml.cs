

   using System;
    using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Threading.Tasks;
    using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.RazorPages;
    using Microsoft.Extensions.Options;
    using Twilio.Rest.Verify.V2.Service;
using WebApp_ServicesAdvertise.AppServices;
using WebApp_ServicesAdvertise.Models;

namespace WebApp_ServicesAdvertise.Areas.Identity.Pages.Account
{
    [Authorize]
    public class ConfirmPhoneModel : PageModel
    {
        private readonly TwilioVerifySettings _settings;
        private readonly UserManager<ApplicationUser> _userManager;
        const string SKConfirmPhoneStartTime = "SKConfirmPhoneStartTime";
        const string SKConfirmPhoneSendAttempts = "SKConfirmPhoneSendAttempts";
        const int maxattemptsFor10Minutes = 3; // for twillio free account, max attempts is 5 for same phone, in 10 minutes. if exceeded the verificationService will be locked and you will recieve an email. then you will have to create a new verificationService in your twilio account
        const int minwaitSecondsForNextAttempt = 30;
        public ConfirmPhoneModel(UserManager<ApplicationUser> userManager, IOptions<TwilioVerifySettings> settings)
        {
            _userManager = userManager;
            _settings = settings.Value;
        }

        public string PhoneNumber { get; set; }
        // [BindProperty, Required, Display(Name = "Code")]
        [BindProperty, Display(Name = "Code")]
        public string VerificationCode { get; set; }


        public async Task<IActionResult> OnGetAsync()
        {
           
            await LoadPhoneNumber();
                return Page();
        }

        


            public async Task<IActionResult> OnPostResendAsync()
        {
            SetSmsAttemptsCount();
            await LoadPhoneNumber();

            try
            {
                var verification = await VerificationResource.CreateAsync(
                    to: PhoneNumber,
                    channel: "sms",
                    pathServiceSid: _settings.VerificationServiceSID
                );

                if (verification.Status == "pending")
                {
                    // return RedirectToPage("ConfirmPhone");
                    ModelState.AddModelError("", DateTime.Now + ": A code was sent to the phone number");
                    return Page();
                }

    ModelState.AddModelError("", $"There was an error sending the verification code: {verification.Status}");
            }
            catch (Exception e)
{
   // ModelState.AddModelError("","There was an error sending the verification code, please check the phone number is correct and try again");
                ModelState.AddModelError("",e.ToString());
                 

            }

return Page();

        }
        
           // public async Task<IActionResult> OnPostAsync()
        public async Task<IActionResult> OnPostConfirmAsync()
            {

                await LoadPhoneNumber();
                if (!ModelState.IsValid)
                {
                    return Page();
                }

                try
                {
                    var verification = await VerificationCheckResource.CreateAsync(
                        to: PhoneNumber,
                        code: VerificationCode,
                        pathServiceSid: _settings.VerificationServiceSID
                    );
                    if (verification.Status == "approved")
                    {
                        var identityUser = await _userManager.GetUserAsync(User);
                        identityUser.PhoneNumberConfirmed = true;
                        var updateResult = await _userManager.UpdateAsync(identityUser);

                        if (updateResult.Succeeded)
                        {
                            return RedirectToPage("ConfirmPhoneSuccess");
                        }
                        else
                        {
                            ModelState.AddModelError("", "There was an error confirming the verification code, please try again");
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", $"There was an error confirming the verification code: {verification.Status}");
                    }
                }
                catch (Exception)
                {
                    ModelState.AddModelError("",
                        "There was an error confirming the code, please check the verification code is correct and try again");
                }

                return Page();
            }

            private async Task LoadPhoneNumber()
            {
                var user = await _userManager.GetUserAsync(User);
                if (user == null)
                {
                    throw new Exception($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
                }
                PhoneNumber = user.PhoneNumber;
            }

        private static void PassTime(DateTime endtime)
        {
            while (DateTime.Now <= endtime)
            {

            }
        }

        private   void SetSmsAttemptsCount()
        {
 // string format = "yyyyMMddHHmmssfff" // for upto milliseconds
            //string dateTime = "20140123205803252";
            // DateTime.ParseExact(dateTime, format, CultureInfo.InvariantCulture);
            // DateTime.Now.ToString("yyyyMMddHHmmss"); string format = "yyyyMMddHHmmssfff"

            //following code is to track begin and endtime, to limit send sms attempts to maxlevel for every 10 minutes , as otherwise the twilio verifyservice will be blocked
            // time is passed to discourage the user from calling sms resend calls several times
            string format = "yyyyMMddHHmmss";

        int attemptscount;
        DateTime startTime = new DateTime();
            try
            {
                attemptscount = (int) HttpContext.Session.GetInt32(SKConfirmPhoneSendAttempts);
    }
            catch (Exception ex) // nullable object must have a value will be the error message
            {
               // ModelState.AddModelError("", ex.ToString());
                attemptscount = 0;
            }

if (attemptscount <= 0)// very first attempt

{
    HttpContext.Session.SetString(SKConfirmPhoneStartTime, DateTime.Now.ToString(format));
    attemptscount = 1;
}
startTime = DateTime.ParseExact(HttpContext.Session.GetString(SKConfirmPhoneStartTime), format, CultureInfo.InvariantCulture);
if (attemptscount <= maxattemptsFor10Minutes)
{
    PassTime(DateTime.Now.AddSeconds(minwaitSecondsForNextAttempt));// time is passed to discourage the user from calling sms resend calls several times
}
else
{
    PassTime(startTime.AddMinutes(10));
    HttpContext.Session.SetString(SKConfirmPhoneStartTime, DateTime.Now.ToString(format));
    attemptscount = 0;
}
attemptscount += 1;
HttpContext.Session.SetInt32(SKConfirmPhoneSendAttempts, attemptscount);
ModelState.AddModelError("", "attempts count " + attemptscount);
        }
           



    }
    }