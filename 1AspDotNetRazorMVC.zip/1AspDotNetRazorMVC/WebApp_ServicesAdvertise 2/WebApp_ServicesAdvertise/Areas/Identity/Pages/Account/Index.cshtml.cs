﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebApp_ServicesAdvertise.Models;

namespace WebApp_ServicesAdvertise.Areas.Identity.Pages.Account
{
    public partial class IndexModel : PageModel
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly IWebHostEnvironment webHostEnvironment;
        private readonly String ProfilePicfoler = "UploadedProfilePics";
      // public IndexModel(IWebHostEnvironment webHostEnvironment)
      //  {
         //   this.webHostEnvironment = webHostEnvironment;
       // }
        public IndexModel(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager, IWebHostEnvironment webHostEnvironment)
        {
            _userManager = userManager; 
            _signInManager = signInManager;
            this.webHostEnvironment = webHostEnvironment;
        }

        public string Username { get; set; }
        public string ImagePath { get; set; }
        public string ImagePath_absolute { get; set; }
        [TempData]
        public string StatusMessage { get; set; }

        [BindProperty]
        public InputModel Input { get; set; }

        public class InputModel
        {
            [Phone]
            [Display(Name = "Phone number")]
            public string PhoneNumber { get; set; }
            [Display(Name = "First Name")]

            public string FirstName { get; set; }
            [Display(Name = "Last Name")]
            public string LastName { get; set; }

            [Display(Name = "Birth Day")]
            [DataType(DataType.Date)]
            [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
            public DateTime BirthDate { get; set; }

            [DataType(DataType.Upload)]
            [Display(Name = "Profile Picture")]
          

            [NotMapped]// to prevent adding a column to table
            [DisplayName("Upload File")]
            public IFormFile ImageFile { get; set; }

        }
        private string GetProfilePicPath_createDirIfNotExist(String FileName)
        {
            /* local variable declaration */
            //var basePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory + "/UploadedProfilePics/");
           // var basePath = System.Reflection.Assembly.GetExecutingAssembly().Location;

            string wwwRootPath = webHostEnvironment.WebRootPath;
            string basePath = Path.Combine(wwwRootPath + "\\" + ProfilePicfoler + "\\");
            bool basePathExists = System.IO.Directory.Exists(basePath);
            if (!basePathExists) Directory.CreateDirectory(basePath);
           

            String path = Path.Combine(basePath, FileName);
            //String path = Path.Combine("~" + "/" + ProfilePicfoler + "/", FileName);
            return path;
        }
        private string GetProfilePicPath_ForCSHTMLView(String FileName)
        {
           
            String path = ("~" + "/" + ProfilePicfoler + "/"+FileName);
            return path;
        }

        private string GetProfilePicPath_ForHtmlPagedelete(String FileName)
        {
                    
            String path = Path.Combine(ProfilePicfoler, FileName);
            return path;
        }

        private async Task LoadAsync(ApplicationUser user)
        {
            var userName = await _userManager.GetUserNameAsync(user);
            var phoneNumber = await _userManager.GetPhoneNumberAsync(user);
           // var profilepath = await _userManager.GetImagePathAsync(user);
            Username = userName;
            String path2 = GetProfilePicPath_ForCSHTMLView(user.ImagePath);
            ImagePath_absolute = path2;
            ImagePath = user.ImagePath; //"E:/Mypc_Dil2/2021-10-OnwardsDil2/Mywork-AspWebApps/WebAppAdvertiseServices_resources/WebApp_ServicesAdvertise/WebApp_ServicesAdvertise/bin/Debug/net5.0/UploadedProfilePics/anna-8Ak1i3KLthc-unsplash211210778"; 
            // GetProfilePicPath_createDirIfNotExist(user.ImagePath);
            Input = new InputModel
            {
                PhoneNumber = phoneNumber   //,
                //ImagePath = user.ImagePath
                


        };
        }

        public async Task<IActionResult> OnGetAsync()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
            }
            
           

            await LoadAsync(user);
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
            }

            if (!ModelState.IsValid)
            {
                await LoadAsync(user);
                return Page();
            }




            var phoneNumber = await _userManager.GetPhoneNumberAsync(user);
            if (Input.PhoneNumber != phoneNumber)
            {
                try
                {
                    /*
                    var numberDetails = await PhoneNumberResource.FetchAsync(
                        pathPhoneNumber: new Twilio.Types.PhoneNumber(Input.PhoneNumber),
                        countryCode: Input.PhoneNumberCountryCode,
                        type: new List<string> { "carrier" });

                    // only allow user to set phone number if capable of receiving SMS
                    var phoneNumberType = numberDetails.GetPhoneNumberType();
                    if (phoneNumberType != null
                        && phoneNumberType == PhoneNumberResource.TypeEnum.Landline)
                    {
                        ModelState.AddModelError($"{nameof(Input)}.{nameof(Input.PhoneNumber)}",
                            $"The number you entered does not appear to be capable of receiving SMS ({phoneNumberType}). Please enter a different value and try again");
                        return Page();
                    }
                    */ //phoneNumber number validation by country code
                   // var numberToSave = numberDetails.PhoneNumber.ToString();
                    var numberToSave = Input.PhoneNumber.ToString();
                    var setPhoneResult = await _userManager.SetPhoneNumberAsync(user, numberToSave);
                    if (!setPhoneResult.Succeeded)
                    {
                        var userId = await _userManager.GetUserIdAsync(user);
                        throw new InvalidOperationException($"Unexpected error occurred setting phone number for user with ID '{userId}'.");
                    }
                }
                // catch (ApiException ex)
                catch (Exception ex)
                {
                    ModelState.AddModelError($"{nameof(Input)}.{nameof(Input.PhoneNumber)}",
                        $"Erro occured while setting the phone number. Please check it and try again");
                   // $"The number you entered was not valid (Twilio code {ex.Code}), please check it and try again");
                    return Page();
                }
            }




            IFormFile file = Input.ImageFile;

            if (file != null)

            { 

            // var basePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory  + "/UploadedProfilePics/");
            // bool basePathExists = System.IO.Directory.Exists(basePath);
            //if (!basePathExists) Directory.CreateDirectory(basePath);

            string fileName; //= Path.GetFileNameWithoutExtension(file.FileName);



            //  _userManager.GetUserId(User)
            fileName = user.ImagePath;
    String path = GetProfilePicPath_createDirIfNotExist(fileName);
               // ImagePath_absolute = path;
   FileInfo fileinfo = new FileInfo(path);
            if (fileinfo.Exists)//check file exsit or not  
            {
                fileinfo.Delete();
        }


 fileName = Path.GetFileNameWithoutExtension(file.FileName);
string extension = Path.GetExtension(file.FileName);
                user.ImagePath = fileName = Guid.NewGuid().ToString() + extension;//global unique Id
                //user.ImagePath =  fileName = fileName + DateTime.Now.ToString("yymmssfff") + extension;
               
               ImagePath = GetProfilePicPath_createDirIfNotExist(user.ImagePath);

                path = GetProfilePicPath_createDirIfNotExist(fileName);// Path.Combine(basePath, fileName);
                ImagePath_absolute = GetProfilePicPath_ForCSHTMLView(fileName);
                using (var fileStream = new FileStream(path, FileMode.Create))
            {
                await file.CopyToAsync(fileStream);
            }
            }

            await _userManager.UpdateAsync(user); 
            // unito Work.Save();
           
            await _signInManager.RefreshSignInAsync(user);
            StatusMessage = "Your profile has been updated";
            return RedirectToPage();
        }
    }
}
