﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace Identity.Email
{
    public class EmailHelper
    {
        public string SendEmail(string userEmail, string confirmationLink)
        {
            string erm = "";
            try
            {
                NetworkCredential login = new NetworkCredential("lalanthadilrukshi@gmail.com", "738181948v");

                System.Net.Mail.MailMessage email = new System.Net.Mail.MailMessage();

                email.To.Add(new MailAddress(userEmail));
                email.From = new MailAddress("lalanthadilrukshi@gmail.com");
                email.Subject = "Question";

                email.Body = "anything";

                // To send through your gmail account, you need to connect to port 587:
                SmtpClient client = new SmtpClient("smtp.gmail.com");
              //  SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
                //SmtpClient client = new SmtpClient("smtp.gmail.com");
                // client.EnableSsl = true;
                client.EnableSsl = false;
                client.UseDefaultCredentials = false;
                client.Credentials = login;
                client.Send(email);



                /*
                //Create the msg object to be sent
                MailMessage msg = new MailMessage();
                //Add your email address to the recipients
                msg.To.Add(userEmail);
                //Configure the address we are sending the mail from
                MailAddress address = new MailAddress("lalanthadilrukshi@gmail.com");
                msg.From = address;
                msg.Subject = "anything";
                msg.Body = "anything";

                //Configure an SmtpClient to send the mail.
                SmtpClient client = new SmtpClient();
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.EnableSsl = false;
                client.Host = "relay-hosting.secureserver.net";
                client.Port = 25;

                //Setup credentials to login to our sender email address ("UserName", "Password")
                NetworkCredential credentials = new System.Net.NetworkCredential("lalanthadilrukshi@gmail.com", "738181948v");
                client.UseDefaultCredentials = true;
                client.Credentials = credentials;

                //Send the msg
                client.Send(msg);
                return erm;// true;
                //Display some feedback to the user to let them know it was sent
                //Label1.Text = "Your message was sent!";
                */
            }
            catch (Exception ex)
            {
                //If the message failed at some point, let the user know
                //Label1.Text = ex.ToString();
                //"Your message failed to send, please try again."
                erm = ex.Message;
            }

            /*
            MailMessage mailMessage = new MailMessage();
           // mailMessage.From = new MailAddress("care@yogihosting.com");
           // mailMessage.From = new MailAddress("dilrukshiprr@yahoo.com");
            mailMessage.From = new MailAddress("lalanthadilrukshi@gmail.com");
            mailMessage.To.Add(new MailAddress(userEmail));

            mailMessage.Subject = "Confirm your email";
            mailMessage.IsBodyHtml = true;
            mailMessage.Body = confirmationLink;

            SmtpClient client = new SmtpClient();
            client.Credentials = new System.Net.NetworkCredential("lalanthadilrukshi@gmail.com", "738181948v");
            client.Host = "	smtp.gmail.com";// "smtpout.secureserver.net";
            client.Port = 587;// 80;
           

            try
            {
                client.Send(message);
                return true;
            }
            catch (Exception ex)
            {
               
                // log exception
            } */
            return erm;
        }
    }
}